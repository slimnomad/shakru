Green Asian Wok — selected design 2

Plain HTML, CSS and JavaScript. No framework required.
Extract the complete folder and open index.html in a modern browser, or serve this folder with any static server.

Files: index.html, src/style.css, src/script.js. Keep assets/ beside index.html. All fonts, images, icons and licenses are included.

Menu search, category filters, dish details and live side pricing work locally. Ordering continues on the restaurant official ordering page; selections are repeated there. No payment or order is simulated.

11 automated tests and desktop/mobile browser QA passed. The complete development project and design evidence are in green-asian-wok-site/ in the original workspace.
